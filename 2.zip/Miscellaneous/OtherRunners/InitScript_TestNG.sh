#!/bin/bash

java -cp ".;./supportlibraries/External_Jars/*" org.testng.TestNG testng_regression.xml